var usageByNeigh = {}
// var incomeByNeigh = {}
var color1 = d3.scale.threshold()
    .domain([1, 2, 3, 4, 5])
    .range(["#f2f0f7", "#dadaeb", "#bcbddc", "#9e9ac8", "#756bb1", "#54278f"]);

console.log(color1(2.76254));
var width = 1000,
    height = 600,
    centered;
    gridSize = Math.floor(width / 25),
    legendWidth = (gridSize/2 + 4)


var tip1 = d3.tip()
  .attr('class', 'd3-tip1')
  .offset([-10, 0])
  .html(function(d) {
  return "<strong>Neighbourhood:</strong> <span style='color:red'>" + d.properties.NAME +"<br>"+ "</span>"+
           "<strong>Borough:</strong> <span style='color:red'>" + d.properties.CITY + "<br>"+"</span>"+
           "<strong>Taxi Usage:</strong> <span style='color:red'>" + usageByNeigh[d.properties.NAME]+"<br>"+"</span>"
    
  });
// var tip2= d3.tip()
//   .attr('class', 'd3-tip2')
//   .offset([-10, 0])
//   .html(function(d) {
//     return "<strong>Neighbourhood:</strong> <span style='color:red'>" + d.properties.NAME +"<br>"+ "</span>"+
//            "<strong>Borough:</strong> <span style='color:red'>" + d.properties.CITY + "<br>"+"</span>"+
//            "<strong>Taxi Usage:</strong> <span style='color:red'>" + usageByNeigh[d.properties.NAME]+"<br>"+"</span>"+
//            "<strong>Median Household Income:</strong> <span style='color:red'>" +"$"+ incomeByNeigh[d.properties.NAME]/100000+ "<br>"+"</span>"
//   });


var projection = d3.geo.transverseMercator()
    .rotate([50,-150])
    .scale(1)
    .translate([0, 0]);
var path = d3.geo.path().projection(projection)


var zoom = d3.behavior.zoom()
    .translate([0, 0])
    .scale(1)
    .scaleExtent([1, 20])
    .on("zoom", zoomed);

var svg = d3.select("body").append("svg")
    .attr("width", width)
    .attr("height", height);
var dis = svg.append("g")
    .attr("width", width)
    .attr("height", height)
    .on("click", clicked)
    .call(tip1);
    // .call(tip2);
var g = svg.append("g").call(zoom);


var legend = svg.selectAll(".g").data([1]).enter().append("legend")
  .attr("class","rect")
    .attr("width", 100)
    .attr("height", 100)
    .attr("x",500)
    .attr("y",300)
    .style("fill","black");

queue()
    .defer(d3.json, "./topo/T2.json")
    .defer(d3.csv,"./data/usage.csv")
    .await(ready);

    function ready(error, ny,usg) {
    //read data from taxiusage file,income file,add file name
      // ny.objects.neighborhood.geometries.forEach(function(d) { usageByNeigh[d.properties.NAME] = +d.properties.REGIONID; });
            // ny.objects.neighborhood.geometries.forEach(function(d) { incomeByNeigh[d.properties.NAME] = +d.properties.REGIONID; });

      // usg.forEach(function(d) { incomeByNeigh[d.properties.NAME] = +d[1]; });
      usg.forEach(function(d){usageByNeigh[d.Neighborhood] = +d.revenue});
      // usg.forEach(function(d){console.log(d.Neighborhood);});


      var tracts = topojson.feature(ny, ny.objects.neighborhood);
       var b = path.bounds(tracts),
          s = .95 / Math.max((b[1][0] - b[0][0]) / width, (b[1][1] - b[0][1]) / height),
          t = [(width - s * (b[1][0] + b[0][0])) / 2, (height - s * (b[1][1] + b[0][1])) / 2];
    
    projection
      .scale(s)
      .translate(t);

      g.append("g")
      .attr("class", "county")
      .selectAll("paths")
      .data(topojson.feature(ny, ny.objects.neighborhood).features)
      .enter().append("path")
      .attr("class", "nieghbourhood")
      .attr("data-neighbourhood", function(d) {return d.properties.NAME; })
      .attr("data-borough", function(d) {return d.properties.CITY; })
      .attr("d", path)
      .style("fill",function(d) { return color1(usageByNeigh[d.properties.NAME]/10000);})
      .on("click", clicked)
      .on('mouseover', tip1.show)
      .on('mouseout', tip1.hide);

  }
 //      g.append("g")
 //      .attr("class","centre")
 //      .selectAll("circle")
 //      .data(topojson.feature(ny, ny.objects.neighborhood).features)
 //      .enter().append("circle")
 //      .attr("class","centroid")
 //      .style("fill","orange")
 //      .attr("transform", function(d) { return "translate(" + path.centroid(d) + ")"; })
 //      .attr("r", function(d) { return incomeByNeigh[d.properties.NAME]/100000; })
 //      .on("click", clicked)
 //      .on('mouseover', tip2.show)
 //      .on('mouseout', tip2.hide);
    
 // }



function zoomed() {
  g.attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
  g.select(".state-border").style("stroke-width", 1.5 / d3.event.scale + "px");
  g.select(".county-border").style("stroke-width", .5 / d3.event.scale + "px");
}


function clicked(d) {
  var x, y, k;

  if (d && centered !== d) {
    var centroid = path.centroid(d);
    x = centroid[0];
    y = centroid[1];
    k = 20;
    centered = d;
  } else {
    x = width / 2;
    y = height / 2;
    k = 1;
    centered = null;
  }

  g.selectAll("path")
      .classed("active", centered && function(d) { return d === centered; });

  g.transition()
      .duration(750)
      .attr("transform",function() {console.log ("translate(" + width / 2 + "," + height / 2 + ")scale(" + k + ")translate(" + -x + "," + -y + ")");return "transform", "translate(" + width / 2 + "," + height / 2 + ")scale(" + k + ")translate(" + -x + "," + -y + ")"})
      .style("stroke-width", 1.5 / k + "px");
}
